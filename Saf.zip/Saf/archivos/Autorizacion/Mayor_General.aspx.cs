﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using archivos.Capa_Datos;

namespace archivos.Autorizacion
{
    public partial class Mayor_General : System.Web.UI.Page
    {
        DataClassesSafDataContext db = new DataClassesSafDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button_Buscar_Click(object sender, EventArgs e)
        {

            DateTime fECHA_INICIO = Convert.ToDateTime(TextBox_INICIAL.Text);
            DateTime fECHA_FINAL = Convert.ToDateTime(TextBox_FINAL.Text);
            string CODIGO_DETALLE_CUENTA_CONTROL_IN = TextBox_C_INICIAL.Text == "" ? null : TextBox_C_INICIAL.Text;
            string CODIGO_DETALLE_CUENTA_CONTROL_FN = TextBox_C_FINAL.Text == "" ? null : TextBox_C_FINAL.Text;

            if (validar_datos())
            {
                var query = (from dto in db.P_MAYOR_GENERAL(fECHA_INICIO, fECHA_FINAL, CODIGO_DETALLE_CUENTA_CONTROL_IN, CODIGO_DETALLE_CUENTA_CONTROL_FN) select dto).ToList();
                db.SubmitChanges();
                GridView_Detalle.DataSource = query;
                GridView_Detalle.DataBind();


                lbl_error.Text = "";
            }
        }


        private Boolean validar_datos()
        {


            if (TextBox_INICIAL.Text == "")
            {
                lbl_error.Text = ("Debe seleccionar un Asiento Contable");
                lbl_aviso.Text = "";

                return false;

            }
            return true;
        }
        protected void lnk_onClick_Detalle(object sender, EventArgs e)
        {

            try
            {
                int id = Convert.ToInt32((sender as LinkButton).CommandArgument);


                var query = (from dto in db.P_SELECT_ID_ASIENTO_FINAL(id) select dto).ToList();
                db.SubmitChanges();
                GridView_Detalle_Asiento.DataSource = query;
                GridView_Detalle_Asiento.DataBind();
                lbl_error.Text = "";
            }
            catch (Exception ex)
            {

                lbl_error.Text = "Error tienes que seleccionar un asiento, " + ex.Message;
            }
            finally
            {
            }
        }
        private Boolean validar_Asiento()
        {


            if (TextBox_INICIAL.Text == "")
            {
                lbl_error.Text = ("Debe seleccionar un Asiento Contable");
                lbl_aviso.Text = "";

                return false;

            }
            return true;
        }
    }
}