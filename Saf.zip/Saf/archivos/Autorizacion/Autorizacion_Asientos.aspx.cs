﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using archivos.Capa_Datos;

namespace archivos.Autorizacion
{
    public partial class Autorizacion_Asientos : System.Web.UI.Page
    {
        DataClassesSafDataContext db = new DataClassesSafDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Lista_Asientos();
            }
        }
        private void Lista_Asientos()
        {


            var query = (from dto in db.P_SELECT_DIARIO_FINAL_ESTADO_0() select dto).ToList();
            db.SubmitChanges();
            GridView_Asientos.DataSource = query;
            GridView_Asientos.DataBind();


        }



        //---------------------------Muestra detalle de asiento -------------------------------------------------------------------//
        protected void lnk_onClick_Detalle(object sender, EventArgs e)
        {
            int id = Convert.ToInt32((sender as LinkButton).CommandArgument);


            var query = (from dto in db.P_SELECT_ID_ASIENTO_FINAL(id) select dto).ToList();
            db.SubmitChanges();
            GridView_Detalle.DataSource = query;
            GridView_Detalle.DataBind();


        }
        //---------------------------Canbiar estado del Asiento -------------------------------------------------------------------//
    }
}