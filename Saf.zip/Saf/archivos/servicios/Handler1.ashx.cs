﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Web;
using System.Web.Script.Serialization;

namespace Cementerios.servicios
{
    /// <summary>
    /// Summary description for Handler1
    /// </summary>
    public class Handler1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {

            string cs = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))

            {
                SqlCommand cmd = new SqlCommand("P_GET_FOTO_BY_ID_PERSONA_GIS", con);

                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter prid = new SqlParameter("@ID_PUESTO_SERVICIOS", context.Request.QueryString["idp"]);
                cmd.Parameters.Add(prid);

                con.Open();
                try
                {
                    byte[] FOTO = (byte[])cmd.ExecuteScalar();
                    con.Close();
                    context.Response.ContentType = "image/jpeg";
                    //context.Response.ContentType = "image/png";
                    context.Response.OutputStream.Write(FOTO, 0, FOTO.Length);
                }
                catch (Exception)
                {

                }
                
            }
             
            



        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}