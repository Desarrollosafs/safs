﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

using Archivo.Central.Layers.Application;


namespace Archivo.Central.Layers.Data
{

    #region    Constructor de la Clase Principal ClassData

    /// <summary>
    /// Constructor de la Clase Principal ClassData
    /// </summary>
    public class ClassData
    {
        // Inicializando el Objeto OracleConnection y Enviando el getConnection Como Parametro

        public static string stringSqlConnection;
        protected static SqlConnection sqlConnection = new SqlConnection(getConnection());

        //Inicializando el Objeto OracleConnection y Enviando el getConnection Como Parametro


        #region    Este procedimiento se utilizara para realizar las operaciones de Insert, Delete, Update

        /// <summary>
        /// Este procedimiento se utilizara para realizar las operaciones de Insert, Delete, Update
        /// </summary>
        /// <param name="stringParamSentenciaSQL"></param>
        /// <param name="SqlParameterlist"></param>
        public static void executeSqlCommand(string stringParamSentenciaSQL, List<SqlParameter> SqlParameterlist = null, string stringParamCommandType = "CommandText")
        {
            SqlCommand sqlCommand = new SqlCommand(stringParamSentenciaSQL, sqlConnection);
            if (sqlConnection.State != ConnectionState.Open)
            {

                sqlConnection.Open();
            }

            try
            {

                sqlCommand.CommandText = stringParamSentenciaSQL;
                sqlCommand.CommandType = stringParamCommandType == "CommandText" ? CommandType.Text : CommandType.StoredProcedure;

                if (SqlParameterlist != null)
                {
                    foreach (SqlParameter sqlParameter in SqlParameterlist)
                    {

                        sqlCommand.Parameters.Add(sqlParameter);
                    }
                }

                sqlCommand.ExecuteNonQuery();

            }
            catch (SqlException sqlException)
            {

                throw sqlException;
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message.ToString());
            }
            finally
            {

                sqlConnection.Close();
                sqlCommand.Dispose();
                //Auditoria y Manejo de Error
            }

        }

        #endregion Este procedimiento se utilizara para realizar las operaciones de Insert, Delete, Update


        #region    Este Metodo se aplica para las Consultas con un DataTable

        /// <summary>
        /// Este Metodo se aplica para las Consultas con un DataTable
        /// </summary>
        /// <param name="stringSentencia"></param>
        /// <param name="SqlParameterlist"></param>
        /// <returns></returns>
        public static DataTable getSqlDataTable(string stringSentencia, List<SqlParameter> SqlParameterlist = null, string stringCommandType = "CommandText")
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dataTable = new DataTable();
            try
            {

                sqlDataAdapter.SelectCommand = new SqlCommand(stringSentencia, sqlConnection);
                sqlDataAdapter.SelectCommand.CommandType = stringCommandType == "CommandText" ? CommandType.Text : CommandType.StoredProcedure;

                if (SqlParameterlist != null)
                {
                    foreach (SqlParameter sqlParameter in SqlParameterlist)
                    {

                        sqlDataAdapter.SelectCommand.Parameters.Add(SqlParameterlist);
                    }
                }

                sqlDataAdapter.Fill(dataTable);

            }
            catch (SqlException sqlException)
            {
                throw  new Exception(sqlException.Message);
            }

            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {
                sqlDataAdapter.Dispose();
                sqlConnection.Close();
                //Auditoria y Manejo de Error
            }

            return dataTable;
        }

        #endregion Este Metodo se aplica para las Consultas con un DataTable


        #region    Este Metodo se aplica para las Consultas con un DataSet

        /// <summary>
        /// Este Metodo se aplica para las Consultas con un DataTable
        /// </summary>
        /// <param name="stringSentencia"></param>
        /// <param name="sqlParameterlist"></param>
        /// <returns></returns>
        public static DataSet getDataSet(string stringParamSentencia, List<SqlParameter> sqlParameterlist = null, string stringParamCommandType = "CommandText")
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataSet dataSet = new DataSet();
            try
            {

                sqlDataAdapter.SelectCommand = new SqlCommand(stringParamSentencia, sqlConnection);
                sqlDataAdapter.SelectCommand.CommandType = stringParamCommandType == "CommandText" ? CommandType.Text : CommandType.StoredProcedure;
                if (sqlParameterlist != null)
                {
                    foreach (SqlParameter oracleParameter in sqlParameterlist)
                    {
                        sqlDataAdapter.SelectCommand.Parameters.Add(sqlParameterlist);
                    }
                }
                sqlDataAdapter.Fill(dataSet);

            }
            catch (SqlException sqlException)
            {

                throw sqlException;
            }

            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {

                sqlDataAdapter.Dispose();
                sqlConnection.Close();
                //Auditoria y Manejo de Error
            }

            return dataSet;
        }

        #endregion Este Metodo se aplica para las Consultas con un DataSet


        #region    Este Metodo se aplica para las Consultas con un DataReader

        /// <summary>
        /// Este Metodo se aplica para las Consultas con un DataReader
        /// </summary>
        /// <param name="stringParamSentencia"></param>
        /// <param name="SqlParameterList"></param>
        /// <param name="stringParamCommandType"></param>
        /// <returns></returns>
        public static SqlDataReader getSqlDataReader(string stringParamSentencia, List<SqlParameter> SqlParameterList = null, string stringParamCommandType = "CommandText", string stringParamCursor = "")
        {
            // Declaracion Local de Objetos, Instancias, Variables y Constantes
            SqlDataReader sqlDataReader = null;
            SqlCommand sqlCommand = new SqlCommand(stringParamSentencia, sqlConnection);

            stringParamCommandType = stringParamCommandType.ToLower();


            // Logica Principal
            if (sqlConnection.State != ConnectionState.Open)
            {
                sqlConnection.Open();
            }

            try
            {

                if (SqlParameterList != null)
                {

                    foreach (SqlParameter sqlParameter in SqlParameterList)
                    {
                        sqlCommand.Parameters.Add(sqlParameter);
                    }
                }

                sqlCommand.CommandType = stringParamCommandType == "commandtext" ? CommandType.Text : CommandType.StoredProcedure;

                if (stringParamCommandType == "storedprocedure" && !string.IsNullOrEmpty(stringParamCursor))
                {

                    sqlCommand.Parameters.Add(SqlParameterList);
                }

                sqlDataReader = sqlCommand.ExecuteReader();
            }
            catch (SqlException sqlException)
            {

                throw sqlException;
            }

            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {
                sqlCommand.Dispose();
                //sqlDataReader.Close();
                //Auditoria y Manejo de Error
            }

            return sqlDataReader;
        }

        #endregion Este Metodo se aplica para las Consultas con un DataReader


        #region    Función Para Obtener el ConnectionString  para Conectar al Servidor Desde el Archivo Xml

        /// <summary>
        /// Función Para Obtener el ConnectionString  para Conectar al Servidor Desde el Archivo Xml
        /// </summary>
        /// <returns></returns>
        public static string getConnection(string stringParamConexion = "sqlServer")
        {
            return ClassApplication.searchIntoNodeAppConfigXml(stringParamConexion);
        }

        #endregion Función Para Obtener el ConnectionString  para Conectar al Servidor Desde el Archivo Xml


        public static DataSet getDataParametersList(string stringProcedure, List<SqlParameter> SqlParameterlist = null)
        {

            SqlDataAdapter da = new SqlDataAdapter(stringProcedure, sqlConnection);
            DataSet Ds = null;

            try
            {
                da.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (SqlParameterlist != null)
                {
                    foreach (SqlParameter sqlParameter in SqlParameterlist)
                    {
                        da.SelectCommand.Parameters.Add(sqlParameter);
                    }
                }

                Ds = new DataSet();
                da.Fill(Ds);
            }
            catch (Exception ex)
            {
                throw new Exception("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
                da.Dispose();
                Ds.Dispose();
            }

            return Ds;
        }

    }

    #endregion Constructor de la Clase Principal ClassData

}

