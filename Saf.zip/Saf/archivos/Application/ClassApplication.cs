﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Xml;

namespace Archivo.Central.Layers.Application
{

   public static class ClassApplication
    {
         //Declaracion de variables 
        static string stringDirectory = searchBaseDirectory() + "//Xml//";
        //Declaracion de variables 

        #region    Metodo para crear busqueda de nodos en el xml

        /// <summary>
        /// Metodo para crear busqueda de nodos en el xml, el cual acepta un parametro el nodo a buscar
        /// </summary>
        /// <param name="stringParamNode"></param>
        /// <returns></returns>
        public static string searchIntoNodeAppConfigXml(string stringParamNode)
        {
            //Declaración de Variables Locales
            string stringNodeResult = string.Empty;
            //Declaración de Variables Locales

            //Declaración de Objetos
            XmlNodeList xmlNodeList = default(XmlNodeList);
            XmlDocument xmlDocument = new XmlDocument();

            try
            {
                xmlDocument.Load(searchBaseDirectory() + @"\\Xml\\AppConfig.xml");
                xmlNodeList = xmlDocument.GetElementsByTagName(stringParamNode);
                stringNodeResult = xmlNodeList[0].InnerText;

            }
            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {
                //Auditoria
            }
            return stringNodeResult;
        }

        #endregion Metodo para crear busqueda de nodos en el xml


        #region    Metodo para buscar el Directorio Base de la Aplicación

        /// <summary>
        /// Metodo para buscar el Directorio Base de la Aplicación
        /// </summary>
        /// <returns></returns>
        public static string searchBaseDirectory()
        {
            //Declaración de Variables Locales
            string stringBaseDirectory;
            string stringPath = AppDomain.CurrentDomain.BaseDirectory;
            //Declaración de Variables Locales

            try
            {
                if (stringPath.IndexOf("bin") > 0)
                {

                    stringBaseDirectory = stringPath.Substring(0, stringPath.IndexOf("bin"));
                }
                else
                {
                    stringBaseDirectory = stringPath;
                }
            }
            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {
                //Auditoria
            }
            return stringBaseDirectory;
        }

        #endregion Metodo para buscar el Directorio Base de la Aplicación


        #region    Creacion del metodo Booleano para la verificación del xml

        /// <summary>
        /// Creacion del metodo para la verificación del xml
        /// </summary>
        /// <returns></returns>
        public static Boolean verifyAppConfigXml()
        {
            try
            {
                if (System.IO.File.Exists(stringDirectory + "AppConfig.xml") == true)
                {
                    return false;
                }
                else
                {

                    ClassApplication.createAppConfigXml("AppConfig.xml");
                }

            }
            catch (Exception exception)
            {

                throw new Exception(exception.Message);
            }
            finally
            {
                //Auditoria
            }
            return true;
        }

        #endregion Creacion del metodo Booleano para la verificación del xml


        #region    Creacion del Xml

        /// <summary>
        /// Creacion del Xml, el cual tiene tiene un parametro archivoXml
        /// </summary>
        /// <param name="stringParamArchivoXml"></param>
        /// <returns></returns>
        public static Boolean createAppConfigXml(string stringParamArchivoXml)
        {
            XmlTextWriter xmlTextWriter = new XmlTextWriter(stringDirectory + stringParamArchivoXml, Encoding.UTF8);
            try
            {
                xmlTextWriter.Formatting = Formatting.Indented;
                xmlTextWriter.WriteStartDocument(false);
                if (stringParamArchivoXml == "AppConfig.xml")
                {
                    xmlTextWriter.WriteStartElement("Configuration");
                    xmlTextWriter.WriteStartElement("appSettings");

                    xmlTextWriter.WriteElementString("Aplicacion", "PEMICA");
                    xmlTextWriter.WriteElementString("Titulo", "Aplicación Registro y control de Imágenes B-scan");
                    xmlTextWriter.WriteElementString("Version", "v1.0");

                    xmlTextWriter.WriteStartElement("Modulos");
                    xmlTextWriter.WriteStartElement("Modulo");
                    xmlTextWriter.WriteElementString("IdModulo", "01");
                    xmlTextWriter.WriteElementString("NombreModulo", "Control de Imagenes b-scan");
                    xmlTextWriter.WriteElementString("Direccion1", "REPÚBLICA DOMINICANA: +1 (809) 262-1771 / +1 (809) 566-1771");
                    xmlTextWriter.WriteElementString("Direccion2", "PANAMÁ: +507 6677-1750 | PEMICA RIF. J-00245337-0");
                    xmlTextWriter.WriteEndElement();

                    xmlTextWriter.WriteEndElement();

                    xmlTextWriter.WriteStartElement("Mensajeria");
                    xmlTextWriter.WriteElementString("From", "b-scan-aila@dncd.mil.do");
                    xmlTextWriter.WriteElementString("To", "cicc@dncd.mil.do");
                    xmlTextWriter.WriteElementString("Cc", "sub-cicc@dncd.mil.do;cuerpo-medico@dncd.mil.do");
                    xmlTextWriter.WriteElementString("Subject", "subject");
                    xmlTextWriter.WriteElementString("MessageMail", "<!DOCTYPE html><html><head><link rel=" + "stylesheet" + " href=" + "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" + "/><link rel=" + "stylesheet" + " href=" + "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css" + "/>" +
			"<script src="+"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"+"></script><meta charset="+"utf-8"+"/><meta name="+"viewport"+" content="+"width=device-width, initial-scale=1.0"+"/><title>envio de solicitud de información</title></head>"+			
			"<body><div class="+"container-body container-fluid"+"style="+"margin 0 auto; text-align:center"+"><div class="+"table responsive"+"><div class="+"jumbotron"+"><hr/><h3 class="+"divider"+">Mensaje de Solicitud de información</h3>"+
			"<h4>NAVEGANDO.COM.DO</h4></div><div class="+"container container-fluid"+"><div class="+"jumbotron"+"><table class="+"table-condensed" +"style="+"margin:0 auto;"+"><tr><td>El Contacto :</td><td>@contacto</td>"+
			"</tr><tr><td>Comercio :</td><td>@comerico</td></tr><tr><td>Ciudad :</td><td>@ciudad</td></tr><tr><td>Correo Electronico :</td><td>@mail</td></tr><tr><td>Telefono :</td><td>@telefono</td></tr><tr>"+
			"<td>Preguntas :</td><td>@preguntas</td></tr></table></div></div></div></div><hr/><footer><p> -Navegando.com.do</p></footer></body></html>");

                    xmlTextWriter.WriteStartElement("Message");
                    xmlTextWriter.WriteEndElement();
                    xmlTextWriter.WriteEndElement();
                    xmlTextWriter.WriteEndElement();


                    xmlTextWriter.WriteStartElement("connectionStrings");
                    xmlTextWriter.WriteElementString("Oracle", "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=myhost)(PORT=1522)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=myserver)));USER ID=myuser;PASSWORD=mypass; PERSIST SECURITY INFO=False");
                    xmlTextWriter.WriteElementString("sqlServer", @"Data Source=PROGRAMACION003;Initial Catalog=RAYO_X;User ID=sa;Password=123456789");
                    xmlTextWriter.WriteEndElement();
                    xmlTextWriter.WriteEndElement();
                    xmlTextWriter.WriteEndDocument();
                    xmlTextWriter.Flush();
                    xmlTextWriter.Close();

                }
                else
                {
                    return false;
                }
            }

            catch (Exception iException)
            {
                throw new Exception(iException.Message.ToString());

            }
            finally
            {
                //Auditoria
            }

            return true;
        }

        #endregion Creacion del Xml


        #region    Envio de Correos

       /// <summary>
        /// Envio de Correos
       /// </summary>
       /// <param name="stringBody"></param>
       /// <param name="stringUser"></param>
       /// <returns></returns>
        public static Boolean enviarEmail(string stringBody, string stringUser)
        {


            System.Net.Mail.MailMessage correo = new System.Net.Mail.MailMessage();
            correo.From = new System.Net.Mail.MailAddress("soporte@catastro.gob.do");
            correo.To.Add("soporte@catastro.gob.do");
            correo.Subject = "Error en la Aplicacion (SIC)";
            //txtTexto.Text += "\n\nFecha y hora GMT: " +
                DateTime.Now.ToUniversalTime().ToString("dd/MM/yyyy HH:mm:ss");
                //txtTexto.Text += "\n\n Notificado por: " + stringUser;
                correo.Body = stringBody + "\n\nFecha y hora GMT: " +
                DateTime.Now.ToUniversalTime().ToString("dd/MM/yyyy HH:mm:ss")
                +  "\n\n Notificado por: " + stringUser; ; 
            correo.IsBodyHtml = true;
            correo.Priority = System.Net.Mail.MailPriority.Normal;
            //
            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
            //
            //---------------------------------------------
            // Estos datos debes rellanarlos correctamente
            //---------------------------------------------

            SmtpClient clienteSmtp = new SmtpClient();
            smtp.Host = "200.26.173.5";
            smtp.Port = 25;
            smtp.UseDefaultCredentials = false;
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Credentials = new System.Net.NetworkCredential("soporte@catastro.gob.do", "Soporte12345");
            smtp.EnableSsl = false;

            try
            {
                smtp.Send(correo);
                //LabelError.Text = "Mensaje enviado satisfactoriamente";

                //txtTexto.Text = "";
                //txtDe.Text = "";
            }
            catch (Exception ex)
            {
                return false;
                throw new Exception(ex.Message);
                //LabelError.Text = "ERROR: " + ex.Message;
            }

            return true;

        }

        #endregion Envio de Correos

    }
}
